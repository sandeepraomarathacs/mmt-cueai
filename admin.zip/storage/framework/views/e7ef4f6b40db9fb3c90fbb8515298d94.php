<?php $__env->startSection('title', 'AI Sessions'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body table-responsive p-0">
        <table class="table table-striped mb-0">
            <thead>
            <tr>
                <th>ID</th><th>Title</th><th>User</th><th>Mode</th><th>Source</th><th>Status</th><th>Duration</th><th></th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($session->id); ?></td>
                    <td><?php echo e($session->title); ?></td>
                    <td><?php echo e($session->user?->email); ?></td>
                    <td><?php echo e($session->mode); ?></td>
                    <td><?php echo e($session->source); ?></td>
                    <td><?php echo e($session->status); ?></td>
                    <td><?php echo e(gmdate('H:i:s', $session->duration_seconds)); ?></td>
                    <td><a href="<?php echo e(route('admin.sessions.show', $session)); ?>">View</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="8" class="text-center text-muted py-4">No sessions</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3"><?php echo e($sessions->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\flutter_project\interview\admin\resources\views/admin/sessions/index.blade.php ENDPATH**/ ?>