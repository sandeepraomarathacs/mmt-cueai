<?php $__env->startSection('title', 'Session #'.$session->id); ?>
<?php $__env->startSection('content'); ?>
<div class="card mb-3">
    <div class="card-body">
        <p><strong>Title:</strong> <?php echo e($session->title); ?></p>
        <p><strong>User:</strong> <?php echo e($session->user?->email); ?></p>
        <p><strong>Mode / Source / Status:</strong> <?php echo e($session->mode); ?> / <?php echo e($session->source); ?> / <?php echo e($session->status); ?></p>
        <p><strong>Language:</strong> <?php echo e($session->language); ?></p>
        <?php if($session->context): ?>
            <p><strong>Context:</strong></p>
            <pre class="bg-light p-3 rounded"><?php echo e($session->context); ?></pre>
        <?php endif; ?>
        <?php if($session->summary): ?>
            <p><strong>Summary:</strong></p>
            <pre class="bg-light p-3 rounded"><?php echo e($session->summary); ?></pre>
        <?php endif; ?>
    </div>
</div>

<div class="card">
    <div class="card-header"><strong>Messages</strong></div>
    <div class="card-body">
        <?php $__empty_1 = true; $__currentLoopData = $session->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="border rounded p-3 mb-3">
                <div class="d-flex justify-content-between">
                    <span class="badge text-bg-info"><?php echo e($message->channel); ?></span>
                    <small class="text-muted"><?php echo e($message->created_at); ?></small>
                </div>
                <?php if($message->input): ?>
                    <p class="mt-2 mb-1"><strong>Input</strong></p>
                    <pre class="mb-2"><?php echo e($message->input); ?></pre>
                <?php endif; ?>
                <p class="mb-1"><strong>Answer</strong></p>
                <pre class="mb-0"><?php echo e($message->answer); ?></pre>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-muted mb-0">No messages</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\flutter_project\interview\admin\resources\views/admin/sessions/show.blade.php ENDPATH**/ ?>