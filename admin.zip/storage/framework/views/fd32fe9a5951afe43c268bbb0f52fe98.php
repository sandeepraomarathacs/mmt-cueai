<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-3 col-6">
        <div class="small-box text-bg-primary p-3 mb-3">
            <div class="inner"><h3><?php echo e($usersCount); ?></h3><p>Users</p></div>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="small-box text-bg-success p-3 mb-3">
            <div class="inner"><h3><?php echo e($sessionsCount); ?></h3><p>Sessions</p></div>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="small-box text-bg-warning p-3 mb-3">
            <div class="inner"><h3><?php echo e($liveCount); ?></h3><p>Live</p></div>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="small-box text-bg-danger p-3 mb-3">
            <div class="inner"><h3><?php echo e($messagesCount); ?></h3><p>AI Messages</p></div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header"><strong>Recent Sessions</strong></div>
    <div class="card-body table-responsive p-0">
        <table class="table table-striped mb-0">
            <thead>
            <tr>
                <th>ID</th><th>Title</th><th>User</th><th>Mode</th><th>Source</th><th>Status</th><th></th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $recentSessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($session->id); ?></td>
                    <td><?php echo e($session->title); ?></td>
                    <td><?php echo e($session->user?->email); ?></td>
                    <td><?php echo e($session->mode); ?></td>
                    <td><?php echo e($session->source); ?></td>
                    <td><span class="badge text-bg-secondary"><?php echo e($session->status); ?></span></td>
                    <td><a href="<?php echo e(route('admin.sessions.show', $session)); ?>">View</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center text-muted py-4">No sessions yet</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\flutter_project\interview\admin\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>